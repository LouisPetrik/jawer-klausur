package vererbung;

public class Fahrzeug {
	
	String name; 


	public Fahrzeug(String name) {
		super();
		this.name = name;
	}
	
	public void fahren() {
		System.out.println("Bruumm du huso");
	}
	

	
}
